#pragma once

#include <cmath>
#include <iostream>


double my_norm(const VecDoub& x){
	double sum = 0;
	for (int i = 0; i < x.size(); i++){
		sum += pow(x[i],2);
	}
	return sqrt(sum);
}


// VecDoub operator-(const VecDoub &A,const VecDoub &b)
// {
// 	if(A.size() != b.size()){
// 		cerr << "in prod: the number of rows in A is not equal to the size of vector b" << endl;
// 	}


// 	VecDoub res( A.size() );
// 	for(int n=0;n < A.size(); n++)
// 	{
// 		res[n] = A[n]-b[n];
// 	}
// 	return res;
// }


// VecDoub operator+(const VecDoub &A,const VecDoub &b)
// {
// 	if(A.size() != b.size()){
// 		cerr << "in prod: the number of rows in A is not equal to the size of vector b" << endl;
// 	}

// 	VecDoub res( A.size() );

// 	for(int n=0;n < A.size(); n++)
// 	{
// 		res[n] = A[n]+b[n];
// 	}
// 	return res;
// }



// VecDoub operator*(const double &h, const VecDoub &vec){
	

// 	VecDoub res( vec.size() );
// 	for(int n=0; n < vec.size(); n++)
// 	{
// 		res[n] = vec[n]*h;
// 	}
// 	return res;
// }


// VecDoub operator+(const double &h, const VecDoub &vec){
	
// 	VecDoub res( vec.size() );
// 	for(int n=0; n < vec.size(); n++)
// 	{
// 		res[n] = vec[n]+h;
// 	}
// 	return res;
// }



